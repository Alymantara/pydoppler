__modules__ = ['pydoppler']
from .pydoppler import spruit, rebin_trail, stream, test_data
#import .mynormalize
__version__ = "0.1.3"
