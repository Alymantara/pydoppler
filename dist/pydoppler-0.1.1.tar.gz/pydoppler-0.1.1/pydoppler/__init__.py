__modules__ = ['pydoppler']
from .pydoppler import spruit, rebin_trail, stream, test_data
from .mynormalize import
__version__ = "0.1.1"
